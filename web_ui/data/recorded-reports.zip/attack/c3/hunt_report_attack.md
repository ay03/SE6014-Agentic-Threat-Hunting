# Threat hunt report: attack

**Hypothesis:** An external IP brute-forced SSH on DEMO-SSH and then logged in successfully between 2026-10-25T00:00:00Z and 2026-10-25T01:00:00Z.

| | |
|---|---|
| **Verdict** | Confirmed |
| Confidence | high |
| C2's draft verdict | SUPPORTED (high confidence). C3 review: agrees |
| Analyst review required | yes: a Confirmed verdict is never acted on automatically; C2's free text names entities that appear in no evidence |
| Time window (UTC) | 2026-10-25T00:00:00Z to 2026-10-25T01:00:00Z |
| Planner | llm |
| Verification | mcp, 4/4 claims verified, replay 26/26 identical |

## 1. Summary

The hunt confirmed the hypothesis with high confidence: 4 verified finding(s) support T1078 (Valid Accounts), T1110 (Brute Force). The earliest supporting event is at 2026-10-25T00:10:00.000Z. An analyst should review the findings before acting.

**Why this verdict**

- Every part of the hypothesis has a technique with at least the minimum number of independent verified indicators.
- 1 statement(s) written by C2 name entities that appear in no evidence: C2 run note 1 mentions AG-02, which appear in no evidence.
- C2 reported SUPPORTED (high); C3's re-verification agrees.

## 2. Hunt plan

Techniques tested (required first): `T1110` Brute Force, `T1078` Valid Accounts

Success criteria:

- T1110 (Brute Force): at least 1 independent self-checked indicator(s)
- T1078 (Valid Accounts): at least 1 independent self-checked indicator(s)

Refutation criteria:

- T1110: all required sources and fields covered for the full window AND zero indicators
- T1078: all required sources and fields covered for the full window AND zero indicators

Entities named in the hypothesis: DEMO-SSH

## 3. Coverage

Data sources in scope: {"auth": 35}

| Technique | Required | Sources | Steps ok / total | Verified claims | Independent steps | Min needed | Covered | Gaps | Not testable with this data |
|---|---|---|---|---|---|---|---|---|---|
| T1110 Brute Force | yes | auth | 1/1 | 2 | 2 | 1 | yes | - | - |
| T1078 Valid Accounts | yes | auth | 2/2 | 2 | 2 | 1 | yes | - | - |

Events per index in the requested time. An empty bucket is a gap.

| Index | Events | Buckets | Empty buckets |
|---|---|---|---|
| auth | 35 | 1 | 0 |

## 4. Findings (verified claims)

### T1110 Brute Force

- **C-001** Source 203.0.113.99 produced 30 failed SSH logins
  - first seen: 2026-10-25T00:10:00.000Z, step `T1110-a`, evidence E-T1110-a, E-T1110-a-dd-203.0.113.99
  - query: `attack-0008` aggregate on `security-events-c2test*`, 2026-10-25T00:00:00Z to 2026-10-25T01:00:00Z (DSL in Appendix A)
  - query: `attack-0009` search on `security-events-c2test*`, 2026-10-25T00:00:00Z to 2026-10-25T01:00:00Z (DSL in Appendix A)
  - events: `security-events-c2test-2026.10.26/d7714d41b5a3496f759f872aca8f04877257068c4db4611f489f8b87c7d8c1d2`, `security-events-c2test-2026.10.26/654a877dd9e249f94afe41548159fa5c648b62599c0b93bf1fe6f99edb43f4d9`, `security-events-c2test-2026.10.26/6fe8eb3895eb9539ab4e0632c81968da67151a9d3b24ca1a3c940a213e70af52`, `security-events-c2test-2026.10.26/25e4969b7453fdea26adf50641328d0ebcecc06bca95dace7c9e8999c19e4e1b`, `security-events-c2test-2026.10.26/304e048ac78e5b95b120b63a5ec76b8149a9841bd23d0b2e0f30a3bc5600ef99`, `security-events-c2test-2026.10.26/fca44ba7a585edcd1630df3259286b6a56e003c068a91325a5cb129344613ed4`, `security-events-c2test-2026.10.26/79806b236ad3b7f1a223187bbfdb4319139c3da322276fa74d7c88d7e53f8ca5`, `security-events-c2test-2026.10.26/49f097b4d3907bfd93b28c342e1901bb57fce5aca7812c81ccf7fe638292365a` (+22 more)
  - verifier: replayed aggregate reproduces the bucket key, count and sum; re-fetched all 30 events behind the bucket; all match
- **C-004** Failed SSH login (failure) for demo from 203.0.113.99 on DEMO-SSH continues up to the successful login _(from an LLM-proposed query: a lead, not proof)_
  - first seen: 2026-10-25T00:10:00.000Z, step `AG-02`, evidence E-AG-02
  - query: `attack-0016` search on `security-events-c2test*`, 2026-10-25T00:00:00Z to 2026-10-25T01:00:00Z (DSL in Appendix A)
  - events: `security-events-c2test-2026.10.26/d7714d41b5a3496f759f872aca8f04877257068c4db4611f489f8b87c7d8c1d2`, `security-events-c2test-2026.10.26/654a877dd9e249f94afe41548159fa5c648b62599c0b93bf1fe6f99edb43f4d9`, `security-events-c2test-2026.10.26/6fe8eb3895eb9539ab4e0632c81968da67151a9d3b24ca1a3c940a213e70af52`, `security-events-c2test-2026.10.26/25e4969b7453fdea26adf50641328d0ebcecc06bca95dace7c9e8999c19e4e1b`, `security-events-c2test-2026.10.26/304e048ac78e5b95b120b63a5ec76b8149a9841bd23d0b2e0f30a3bc5600ef99`, `security-events-c2test-2026.10.26/fca44ba7a585edcd1630df3259286b6a56e003c068a91325a5cb129344613ed4`, `security-events-c2test-2026.10.26/79806b236ad3b7f1a223187bbfdb4319139c3da322276fa74d7c88d7e53f8ca5`, `security-events-c2test-2026.10.26/49f097b4d3907bfd93b28c342e1901bb57fce5aca7812c81ccf7fe638292365a` (+22 more)
  - verifier: re-fetched all 30 cited events; all quoted values match

### T1078 Valid Accounts

- **C-002** Source 203.0.113.99 logged in successfully as demo on DEMO-SSH after its failed SSH logins began
  - first seen: 2026-10-25T00:11:00.000Z, step `T1078-b-203.0.113.99`, evidence E-T1078-b-203.0.113.99
  - query: `attack-0012` search on `security-events-c2test*`, 2026-10-25T00:10:00.000Z to 2026-10-25T01:00:00Z (DSL in Appendix A)
  - events: `security-events-c2test-2026.10.26/e8ff3838a95a7b72b6204c9ef80ac770594e12d72f59eb2e415cd574f4ace1f4`
  - verifier: re-fetched all 1 cited events; all quoted values match
- **C-003** Successful authentication on DEMO-SSH from 203.0.113.99 as demo: ssh\_login _(from an LLM-proposed query: a lead, not proof)_
  - first seen: 2026-10-25T00:11:00.000Z, step `AG-01`, evidence E-AG-01
  - query: `attack-0014` search on `security-events-c2test*`, 2026-10-25T00:00:00Z to 2026-10-25T01:00:00Z (DSL in Appendix A)
  - events: `security-events-c2test-2026.10.26/e8ff3838a95a7b72b6204c9ef80ac770594e12d72f59eb2e415cd574f4ace1f4`
  - verifier: re-fetched all 1 cited events; all quoted values match

## 5. Claims the verifier rejected

_No claim was rejected._

## 6. Benign explanations and baselines considered

- step AG-02: result was truncated (5/30); re-queried with size=30

## 7. Verification summary

- Claims: 4 total, 4 verified, 0 unsupported, 0 contradicted, 0 not re-verified
- Query replay: 26 of 26 identical
- Flag `narrative_unsupported_entity`: C2 run note 1 mentions AG-02, which appear in no evidence

## 8. Limitations and data gaps

- Findings depend on the playbooks used; techniques without a playbook are not tested.
- Baselines are synthetic allowlists and must be tuned per environment.
- NOT\_SUPPORTED means no evidence within the covered sources, fields and window, not proof of absence.
- Claims passed C2's structural self-check only; independent re-verification against Elasticsearch is C3's.
- A Refuted verdict means there was no evidence in the covered sources and time window. It does not prove the activity did not happen.
- The verifier checks that cited events exist and contain the quoted values. It cannot check that the playbook read them correctly.
- Some free text written by C2 names IPs, hosts or accounts that appear in no evidence. The verification summary lists them, and an analyst should review them.
- 2 finding(s) come from LLM-proposed queries. They were verified like every claim, but they are leads only.

## Appendix A. Every query executed (24)

| Call | Tool | Index | Total | OK | Result hash |
|---|---|---|---|---|---|
| `attack-0001` | describe_data | - | 35 | yes | `aa6244e314c7bc4f` |
| `attack-0002` | count | security-events-c2test* | 31 | yes | `b22db16bd5e8ddc3` |
| `attack-0003` | aggregate | security-events-c2test* | 35 | yes | `9e4a1cbf40f71ba5` |
| `attack-0004` | count | security-events-c2test* | 35 | yes | `aa6244e314c7bc4f` |
| `attack-0005` | count | security-events-c2test* | 35 | yes | `aa6244e314c7bc4f` |
| `attack-0006` | count | security-events-c2test* | 35 | yes | `aa6244e314c7bc4f` |
| `attack-0007` | count | security-events-c2test* | 35 | yes | `aa6244e314c7bc4f` |
| `attack-0008` | aggregate | security-events-c2test* | 30 | yes | `29777b1343d94f20` |
| `attack-0009` | search | security-events-c2test* | 30 | yes | `a7f06cd2ccf8ecee` |
| `attack-0010` | aggregate | security-events-c2test* | 30 | yes | `29777b1343d94f20` |
| `attack-0011` | search | security-events-c2test* | 30 | yes | `899aa7eb4ae88584` |
| `attack-0012` | search | security-events-c2test* | 1 | yes | `c2424e9d9406544a` |
| `attack-0013` | search | security-events-c2test* | 0 | yes | `3e6758e523312177` |
| `attack-0014` | search | security-events-c2test* | 1 | yes | `c2424e9d9406544a` |
| `attack-0015` | search | security-events-c2test* | 30 | yes | `aa4013c16024d30e` |
| `attack-0016` | search | security-events-c2test* | 30 | yes | `a7f06cd2ccf8ecee` |
| `attack-0017` | search | security-events-c2test* | 0 | yes | `3e6758e523312177` |
| `attack-0018` | aggregate | security-events-c2test* | 33 | yes | `666170ce005bd8b1` |
| `attack-0019` | search | security-events-c2test* | 0 | yes | `3e6758e523312177` |
| `attack-0020` | aggregate | security-events-c2test* | 2 | yes | `f6dfa0ade2be4370` |
| `attack-0021` | aggregate | security-events-c2test* | 33 | yes | `666170ce005bd8b1` |
| `attack-0022` | search | security-events-c2test* | 1 | yes | `c2424e9d9406544a` |
| `attack-0023` | search | security-events-c2test* | 1 | yes | `c2424e9d9406544a` |
| `attack-0024` | search | security-events-c2test* | 30 | yes | `a7f06cd2ccf8ecee` |

<details><summary>Elasticsearch DSL per query</summary>

`attack-0002` count

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "host.name": {
              "case_insensitive": true,
              "value": "DEMO-SSH"
            }
          }
        }
      ]
    }
  }
}
```

`attack-0003` aggregate

```json
{
  "aggs": {
    "a": {
      "date_histogram": {
        "extended_bounds": {
          "max": "2026-10-25T00:59:59.999Z",
          "min": "2026-10-25T00:00:00.000Z"
        },
        "field": "@timestamp",
        "fixed_interval": "60m",
        "min_doc_count": 0
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0004` count

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "exists": {
            "field": "source.ip"
          }
        }
      ]
    }
  }
}
```

`attack-0005` count

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "exists": {
            "field": "event.action"
          }
        }
      ]
    }
  }
}
```

`attack-0006` count

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "exists": {
            "field": "event.outcome"
          }
        }
      ]
    }
  }
}
```

`attack-0007` count

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "exists": {
            "field": "user.name"
          }
        }
      ]
    }
  }
}
```

`attack-0008` aggregate

```json
{
  "aggs": {
    "a": {
      "terms": {
        "field": "source.ip",
        "size": 20
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "host.name": {
                    "case_insensitive": true,
                    "value": "DEMO-SSH"
                  }
                }
              }
            ]
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0009` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "host.name": {
                    "case_insensitive": true,
                    "value": "DEMO-SSH"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        }
      ]
    }
  },
  "size": 100,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0010` aggregate

```json
{
  "aggs": {
    "a": {
      "terms": {
        "field": "source.ip",
        "size": 20
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "host.name": {
                    "case_insensitive": true,
                    "value": "DEMO-SSH"
                  }
                }
              }
            ]
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0011` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "host.name": {
                    "case_insensitive": true,
                    "value": "DEMO-SSH"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        }
      ]
    }
  },
  "size": 1,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0012` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:10:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "host.name": {
                    "case_insensitive": true,
                    "value": "DEMO-SSH"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        }
      ]
    }
  },
  "size": 100,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0013` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "wildcard": {
                  "user_agent.original": {
                    "case_insensitive": true,
                    "value": "*ignore all previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user_agent.original": {
                    "case_insensitive": true,
                    "value": "*ignore previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user_agent.original": {
                    "case_insensitive": true,
                    "value": "*disregard previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user_agent.original": {
                    "case_insensitive": true,
                    "value": "*ignore the above*"
                  }
                }
              },
              {
                "wildcard": {
                  "user_agent.original": {
                    "case_insensitive": true,
                    "value": "*system prompt*"
                  }
                }
              },
              {
                "wildcard": {
                  "user.name": {
                    "case_insensitive": true,
                    "value": "*ignore all previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user.name": {
                    "case_insensitive": true,
                    "value": "*ignore previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user.name": {
                    "case_insensitive": true,
                    "value": "*disregard previous instructions*"
                  }
                }
              },
              {
                "wildcard": {
                  "user.name": {
                    "case_insensitive": true,
                    "value": "*ignore the above*"
                  }
                }
              },
              {
                "wildcard": {
                  "user.name": {
                    "case_insensitive": true,
                    "value": "*system prompt*"
                  }
                }
              },
              {
                "match_phrase": {
                  "message": "ignore all previous instructions"
                }
              },
              {
                "match_phrase": {
                  "message": "ignore previous instructions"
                }
              },
              {
                "match_phrase": {
                  "message": "disregard previous instructions"
                }
              },
              {
                "match_phrase": {
                  "message": "ignore the above"
                }
              },
              {
                "match_phrase": {
                  "message": "system prompt"
                }
              }
            ]
          }
        }
      ]
    }
  },
  "size": 50,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0014` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.dataset": {
              "case_insensitive": true,
              "value": "linux.auth"
            }
          }
        },
        {
          "term": {
            "host.name": {
              "case_insensitive": true,
              "value": "DEMO-SSH"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        }
      ]
    }
  },
  "size": 20,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0015` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.dataset": {
              "case_insensitive": true,
              "value": "linux.auth"
            }
          }
        },
        {
          "term": {
            "host.name": {
              "case_insensitive": true,
              "value": "DEMO-SSH"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        }
      ]
    }
  },
  "size": 5,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0016` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.dataset": {
              "case_insensitive": true,
              "value": "linux.auth"
            }
          }
        },
        {
          "term": {
            "host.name": {
              "case_insensitive": true,
              "value": "DEMO-SSH"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        }
      ]
    }
  },
  "size": 30,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0017` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-24T00:00:00.000Z",
              "lt": "2026-10-25T00:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        },
        {
          "term": {
            "event.category": {
              "case_insensitive": true,
              "value": "authentication"
            }
          }
        }
      ]
    }
  },
  "size": 20,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0018` aggregate

```json
{
  "aggs": {
    "a": {
      "terms": {
        "field": "source.ip",
        "size": 100
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        },
        {
          "term": {
            "event.category": {
              "case_insensitive": true,
              "value": "authentication"
            }
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0019` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-24T00:00:00.000Z",
              "lt": "2026-10-25T00:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "user.name": {
              "case_insensitive": true,
              "value": "demo"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        },
        {
          "term": {
            "host.name": {
              "case_insensitive": true,
              "value": "DEMO-SSH"
            }
          }
        }
      ]
    }
  },
  "size": 20,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0020` aggregate

```json
{
  "aggs": {
    "a": {
      "terms": {
        "field": "source.ip",
        "size": 100
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-18T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "user.name": {
              "case_insensitive": true,
              "value": "demo"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        },
        {
          "term": {
            "event.category": {
              "case_insensitive": true,
              "value": "authentication"
            }
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0021` aggregate

```json
{
  "aggs": {
    "a": {
      "terms": {
        "field": "source.ip",
        "size": 20
      }
    }
  },
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        }
      ]
    }
  },
  "size": 0
}
```

`attack-0022` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:10:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "bool": {
            "minimum_should_match": 1,
            "should": [
              {
                "term": {
                  "event.dataset": {
                    "case_insensitive": true,
                    "value": "linux.auth"
                  }
                }
              }
            ]
          }
        },
        {
          "term": {
            "event.action": {
              "case_insensitive": true,
              "value": "ssh_login"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        }
      ]
    }
  },
  "size": 200,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0023` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.dataset": {
              "case_insensitive": true,
              "value": "linux.auth"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "success"
            }
          }
        }
      ]
    }
  },
  "size": 200,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

`attack-0024` search

```json
{
  "query": {
    "bool": {
      "filter": [
        {
          "range": {
            "@timestamp": {
              "gte": "2026-10-25T00:00:00.000Z",
              "lt": "2026-10-25T01:00:00.000Z"
            }
          }
        },
        {
          "term": {
            "event.dataset": {
              "case_insensitive": true,
              "value": "linux.auth"
            }
          }
        },
        {
          "term": {
            "source.ip": "203.0.113.99"
          }
        },
        {
          "term": {
            "event.outcome": {
              "case_insensitive": true,
              "value": "failure"
            }
          }
        }
      ]
    }
  },
  "size": 200,
  "sort": [
    {
      "@timestamp": {
        "order": "asc"
      }
    },
    {
      "event.original": {
        "order": "asc"
      }
    }
  ],
  "track_total_hits": true
}
```

</details>

## Appendix B. Run metadata

| | |
|---|---|
| run_id | attack |
| backend | llm:openai:deepseek-flash@api.deepseek.com |
| planner | llm |
| code_hash | 77d45cd02dffc406 |
| tool_calls | 27 |
| seconds | 75.2 |
| python | 3.11.16 |
| temperature | 0.0 |
| llm | {'calls': 6, 'max_calls': 8, 'tokens_in': 9482, 'tokens_out': 11086, 'trace': 'runs/attack/llm.jsonl'} |
| controls | {'canonical_order': True, 'coverage_enforcement': True, 'complete_results': True, 'canonical_params': True, 'agent_loop': True, 'skeptic': True, 'act': True, 'deterministic_sampling': True} |
| perturb_seed | None |
| index | security-events-c2test* |
| mcp_servers | {'es': '/tmp/smtd-e2e-20261026-venv/bin/python -m es_mcp_server.server', 'analytics': 'python -m analytics_server.server'} |
| ignored_tools | ['es.get_event', 'es.save_finding', 'es.get_audit_log'] |
| audit_files | ['audit/attack.jsonl', 'audit/attack-analytics.jsonl'] |
| verification_errors | [] |
| report generator | se6014-c3-evidence 1.0.0 |
